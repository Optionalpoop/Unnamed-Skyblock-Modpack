BlockEvents.rightClicked(event => {
    // 1. Check if the player is holding a stick
    if (event.item.id == 'minecraft:stick') {
        
        // 2. Check if the block clicked belongs to the "logs" tag
        // This ensures it works for Oak, Spruce, Birch, etc.
        if (event.block.hasTag('minecraft:logs')) {
            
            // Get the ID of the log (e.g., 'minecraft:oak_log')
            let logId = event.block.id
            // Logic to determine the plank type based on the log name
            // This replaces "_log" or "_wood" with "_planks"
            let plankId = logId.replace('_log', '_planks').replace('_wood', '_planks')

            // 3. Update the block in the world
            event.block.set(plankId)
            
            // 4. Optional: Play a sound and show particles
            event.level.playSound(null, event.block.pos, 'minecraft:ui.stonecutter.take_result', 'blocks', 1.0, 1.0)
            event.server.runCommandSilent(`particle minecraft:block ${logId} ${event.block.x} ${event.block.y} ${event.block.z} 0.2 0.2 0.2 0.1 10`)

            // 5. Swing the player's arm and stop the default interaction (like placing a block)
            event.player.swing()
            event.cancel()
        }
    }
})

ServerEvents.recipes(event => {
  // Define the standard wood types to iterate through
  const woodTypes = [
    'oak',
    'spruce',
    'birch',
    'jungle',
    'acacia',
    'dark_oak',
    'mangrove',
    'cherry'
  ]

  woodTypes.forEach(wood => {
    // Adding recipe for Stripped Logs -> 2 Planks
    event.shapeless(
      Item.of(`minecraft:${wood}_planks`, 2), // Output
      [`minecraft:stripped_${wood}_log`]      // Input
    ).id(`kubejs:stripped_${wood}_log_to_planks`)

    // Adding recipe for Stripped Wood (the 'all-bark' block) -> 2 Planks
    event.shapeless(
      Item.of(`minecraft:${wood}_planks`, 2), // Output
      [`minecraft:stripped_${wood}_wood`]     // Input
    ).id(`kubejs:stripped_${wood}_wood_to_planks`)
  })
})
