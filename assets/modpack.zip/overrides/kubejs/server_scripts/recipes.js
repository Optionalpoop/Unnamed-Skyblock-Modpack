ServerEvents.recipes(event => {
    // Recipe Removals
    event.remove({ id: 'minecraft:oak_planks' })
    event.remove({ id: 'minecraft:birch_planks' })
    event.remove({ id: 'minecraft:dark_oak_planks' })
    event.remove({ id: 'minecraft:spruce_planks' })
    event.remove({ id: 'minecraft:mangrove_planks' })
    event.remove({ id: 'minecraft:cherry_planks' })
    event.remove({ id: 'minecraft:acacia_planks' })
    event.remove({ id: 'minecraft:warped_planks' })
    event.remove({ id: 'minecraft:crimson_planks' })
    event.remove({ id: 'minecraft:jungle_planks' })
    event.remove({ id: 'minecraft:crafting_table' })
    event.remove({ id: 'minecraft:wooden_pickaxe' })
    event.remove({ id: 'minecraft:wooden_hoe' })
    event.remove({ id: 'minecraft:wooden_sword' })
    event.remove({ id: 'minecraft:wooden_axe' })
    event.remove({ id: 'minecraft:wooden_shovel' })
    event.remove({ id: 'minecraft:iron_pickaxe' })
    event.remove({ id: 'minecraft:iron_hoe' })
    event.remove({ id: 'minecraft:iron_sword' })
    event.remove({ id: 'minecraft:iron_axe' })
    event.remove({ id: 'minecraft:iron_shovel' })
    event.remove({ id: 'minecraft:stone_pickaxe' })
    event.remove({ id: 'minecraft:stone_hoe' })
    event.remove({ id: 'minecraft:stone_sword' })
    event.remove({ id: 'minecraft:stone_axe' })
    event.remove({ id: 'minecraft:stone_shovel' })
    event.remove({ id: 'minecraft:diamond_pickaxe' })
    event.remove({ id: 'minecraft:diamond_hoe' })
    event.remove({ id: 'minecraft:diamond_sword' })
    event.remove({ id: 'minecraft:diamond_axe' })
    event.remove({ id: 'minecraft:diamond_shovel' })
    event.remove({ id: 'minecraft:gold_pickaxe' })
    event.remove({ id: 'minecraft:gold_hoe' })
    event.remove({ id: 'minecraft:gold_sword' })
    event.remove({ id: 'minecraft:gold_axe' })
    event.remove({ id: 'minecraft:gold_shovel' })
    event.remove({ id: 'minecraft:chest' })
    event.remove({ id: 'minecraft:barrel' })
    event.remove({ id: 'minecraft:furnace' })
    event.remove({ id: 'create:crafting/kinetics/large_cogwheel' })
    event.remove({ id: 'create:crafting/kinetics/cogwheel' })
    event.remove({ id: 'create:crafting/kinetics/large_cogwheel_from_little' })
    event.remove({ id: 'create:crafting/kinetics/water_wheel' })
    event.remove({ id: 'create:crafting/kinetics/large_water_wheel' })

    // Recipe Additions
    event.shaped(
        Item.of('minecraft:crafting_table'),
        [
            'AA ',
            'BB ',
            '   '
        ],
        {
            A: '#minecraft:planks',
            B: '#minecraft:logs'
        }
    )
    event.shaped(
        Item.of('minecraft:stick', 16),
        [
            'A  ',
            'A  ',
            '   '
        ],
        {
            A: '#minecraft:logs'
        }
    )
    event.shaped(
        Item.of('minecraft:chest'),
        [
            'AAA',
            'ABA',
            'AAA'
        ],
        {
            A: '#minecraft:logs',
            B: 'minecraft:apple'
        }
    )
    event.shaped(
        Item.of('minecraft:dirt', 2),
        [
            'AAA',
            'ABA',
            'AAA'
        ],
        {
            A: '#minecraft:leaves',
            B: 'minecraft:dirt'
        }
    )
    event.shaped(
        Item.of('minecraft:grass_block'),
        [
            'AAA',
            'ABA',
            'AAA'
        ],
        {
            A: 'minecraft:apple',
            B: 'minecraft:dirt'
        }
    )
    event.shaped(
        Item.of('minecraft:water_bucket'),
        [
            'AAA',
            'ABA',
            'AAA'
        ],
        {
            A: '#minecraft:leaves',
            B: 'woodenbucket:wooden_bucket'
        }
    )
    event.shapeless(
        Item.of('minecraft:green_dye', 2),
        [
            'minecraft:blue_dye',
            'minecraft:yellow_dye'
        ]
    )
    event.shapeless(
        Item.of('minecraft:brown_dye', 2),
        [
            'minecraft:red_dye',
            'minecraft:green_dye'
        ]
    )
    event.shapeless(
        Item.of('minecraft:black_dye', 4),
        [
            'minecraft:brown_dye',
            'minecraft:green_dye',
            'minecraft:red_dye',
            'minecraft:yellow_dye'
        ]
    )
    event.shaped(
        Item.of('minecraft:blue_dye'),
        [
            'ACA',
            'CBC',
            'ACA'
        ],
        {
            A: 'minecraft:oak_slab',
            B: 'minecraft:oak_sapling',
            C: 'minecraft:oak_leaves'
        }
    )
    event.shaped(
        Item.of('minecraft:dark_oak_sapling'),
        [
            'AAA',
            'ABA',
            'AAA'
        ],
        {
            A: 'minecraft:black_dye',
            B: 'minecraft:oak_sapling'
        }
    )
    event.shaped(
        Item.of('minecraft:spruce_sapling'),
        [
            'AAA',
            'ABA',
            'AAA'
        ],
        {
            A: 'minecraft:brown_dye',
            B: 'minecraft:oak_sapling'
        }
    )
    event.shaped(
        Item.of('minecraft:jungle_sapling'),
        [
            'AAA',
            'ABA',
            'AAA'
        ],
        {
            A: 'minecraft:green_dye',
            B: 'minecraft:oak_sapling'
        }
    )
    event.shaped(
        Item.of('minecraft:birch_sapling'),
        [
            'AAA',
            'ABA',
            'AAA'
        ],
        {
            A: 'minecraft:yellow_dye',
            B: 'minecraft:oak_sapling'
        }
    )
    event.shaped(
        Item.of('minecraft:acacia_sapling'),
        [
            'AAA',
            'ABA',
            'AAA'
        ],
        {
            A: 'minecraft:orange_dye',
            B: 'minecraft:oak_sapling'
        }
    )
    event.shaped(
        Item.of('minecraft:cherry_sapling'),
        [
            'AAA',
            'ABA',
            'AAA'
        ],
        {
            A: 'minecraft:pink_dye',
            B: 'minecraft:oak_sapling'
        }
    )
    event.shaped(
        Item.of('minecraft:mangrove_propagule'),
        [
            'AAA',
            'ABA',
            'AAA'
        ],
        {
            A: 'minecraft:cyan_dye',
            B: 'minecraft:oak_sapling'
        }
    )
    event.shaped(
        Item.of('minecraft:lava_bucket'),
        [
            'ACA',
            'CBC',
            'ACA'
        ],
        {
            A: 'minecraft:cherry_leaves',
            B: 'minecraft:water_bucket',
            C: 'minecraft:mangrove_log'
        }
    )
    event.shaped(
        Item.of('minecraft:barrel'),
        [
            'AAA',
            'A A',
            'AAA'
        ],
        {
            A: 'minecraft:jungle_planks'
        }
    )
    event.shaped(
        Item.of('minecraft:dirt', 16),
        [
            'AAA',
            'AAA',
            'AAA'
        ],
        {
            A: 'minecraft:dark_oak_leaves'
        }
    )
    event.shaped(
        Item.of('minecraft:andesite', 8),
        [
            'AAA',
            'ABA',
            'AAA'
        ],
        {
            A: 'minecraft:cobblestone',
            B: 'minecraft:light_gray_dye'
        }
    )
    event.shaped(
        Item.of('minecraft:diorite', 8),
        [
            'AAA',
            'ABA',
            'AAA'
        ],
        {
            A: 'minecraft:cobblestone',
            B: 'minecraft:white_dye'
        }
    )
    event.shaped(
        Item.of('minecraft:granite', 8),
        [
            'AAA',
            'ABA',
            'AAA'
        ],
        {
            A: 'minecraft:cobblestone',
            B: 'minecraft:red_dye'
        }
    )
    event.shaped(
        Item.of('minecraft:deepslate', 8),
        [
            'AAA',
            'ABA',
            'AAA'
        ],
        {
            A: 'minecraft:cobblestone',
            B: 'minecraft:black_dye'
        }
    )
    event.shaped(
        Item.of('minecraft:sunflower'),
        [
            'A  ',
            'A  ',
            '   '
        ],
        {
            A: 'minecraft:dandelion',
        }
    )
    event.shaped(
        Item.of('minecraft:rose_bush'),
        [
            'A  ',
            'A  ',
            '   '
        ],
        {
            A: 'minecraft:poppy',
        }
    )
    event.shaped(
        Item.of('minecraft:string', 4),
        [
            'AAA',
            'ABA',
            'AAA'
        ],
        {
            A: 'minecraft:wheat',
            B: 'minecraft:stick'
        }
    )
    event.shaped(
        Item.of('create:andesite_alloy'),
        [
            'BA ',
            'AB ',
            '   '
        ],
        {
            A: 'minecraft:andesite',
            B: 'minecraft:acacia_planks'
        }
    )
    event.shaped(
        Item.of('create:andesite_alloy'),
        [
            'BA ',
            'AB ',
            '   '
        ],
        {
            B: 'minecraft:andesite',
            A: 'minecraft:acacia_planks'
        }
    )
    event.shaped(
        Item.of('create:cogwheel'),
        [
            'BA ',
            '   ',
            '   '
        ],
        {
            B: 'create:shaft',
            A: 'minecraft:spruce_planks'
        }
    )
    event.shaped(
        Item.of('create:large_cogwheel'),
        [
            'BBB',
            'BAB',
            'BBB'
        ],
        {
            B: 'minecraft:spruce_planks',
            A: 'create:shaft'
        }
    )
    event.shaped(
        Item.of('create:water_wheel'),
        [
            'BBB',
            'BAB',
            'BBB'
        ],
        {
            B: 'minecraft:spruce_planks',
            A: 'create:large_cogwheel'
        }
    )
    event.shaped(
        Item.of('create:large_water_wheel'),
        [
            'BBB',
            'BAB',
            'BBB'
        ],
        {
            B: 'minecraft:spruce_planks',
            A: 'create:water_wheel'
        }
    )
})
